Authors
=======

This is the list of OpenSSL authors for copyright purposes.
It does not necessarily list everyone who has contributed code,
since in some cases, their employer may be the copyright holder.
To see the full list of contributors, see the revision history in
source control.

Groups
------

 * OpenSSL Software Services, Inc.
 * OpenSSL Software Foundation, Inc.

Individuals
-----------

 * Andy Polyakov
 * Ben Laurie
 * Ben Kaduk
 * Bernd Edlinger
 * Bodo Möller
 * David Benjamin
 * David von Oheimb
 * Dmitry Belyavskiy (Дмитрий Белявский)
 * Emilia Käsper
 * Eric Young
 * Geoff Thorpe
 * Holger Reif
 * Kurt Roeckx
 * Lutz Jänicke
 * Mark J. Cox
 * Matt Caswell
 * Matthias St. Pierre
 * Nicola Tuveri
 * Nils Larsch
 * Patrick Steuer
 * Paul Dale
 * Paul C. Sutton
 * Paul Yang
 * Ralf S. Engelschall
 * Rich Salz
 * Richard Levitte
 * Shane Lontis
 * Stephen Henson
 * Steve Marquess
 * Tim Hudson
 * Tomáš Mráz
 * Ulf Möller
 * Viktor Dukhovni
